<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	 function __construct() {

	 	parent::__construct();

	 	$this->load->model('common_model');

	}

	public function index()
	{
		$this->load->view('include/front_header');
		$this->load->view('front/index');
		$this->load->view('include/front_footer');
	}
	public function application_preparation()
	{
		$this->load->view('include/front_header');
		$this->load->view('front/application-preparation/index');
		$this->load->view('include/front_footer');
	}
	public function bs_bsc()
	{
		$this->load->view('include/front_header_2');
		$this->load->view('front/application-preparation/bs_bsc');
		$this->load->view('include/front_footer_2');
	}
	public function ms_msc()
	{
		$this->load->view('include/front_header_2');
		$this->load->view('front/application-preparation/ms_msc');
		$this->load->view('include/front_footer_2');
	}
	public function mba_emba()
	{
		$this->load->view('include/front_header_2');
		$this->load->view('front/application-preparation/mba_emba');
		$this->load->view('include/front_footer_2');
	}
	public function phd()
	{
		$this->load->view('include/front_header_2');
		$this->load->view('front/application-preparation/phd');
		$this->load->view('include/front_footer_2');
	}

	public function career_and_school_selection()
	{
		$this->load->view('include/front_header');
		$this->load->view('front/career-and-school-selection/index');
		$this->load->view('include/front_footer');
	}

	public function test_preparation()
	{
		$this->load->view('include/front_header');
		$this->load->view('front/test-preparation/index');
		$this->load->view('include/front_footer');
	}
	public function interview_preparation()
	{
		$this->load->view('include/front_header');
		$this->load->view('front/interview_preparation');
		$this->load->view('include/front_footer');
	}
	public function about_us()
	{
		$this->load->view('include/front_header');
		$this->load->view('front/about-us/index');
		$this->load->view('include/front_footer');
	}
	public function our_students()
	{
		$this->load->view('include/front_header_2');
		$this->load->view('front/about-us/our-students/index');
		$this->load->view('include/front_footer');
	}



   public function renaud_de_peretti()
	{
		$this->load->view('include/front_header_2');
		$this->load->view('front/about-us/our-students/renaud_de_peretti');
		$this->load->view('include/front_footer_2');
	}

	public function wissem_a()
	{
		$this->load->view('include/front_header_2');
		$this->load->view('front/about-us/our-students/wissem_a');
		$this->load->view('include/front_footer_2');
	}

	public function yann_hoarau()
	{
		$this->load->view('include/front_header_2');
		$this->load->view('front/about-us/our-students/yann_hoarau');
		$this->load->view('include/front_footer_2');
	}

   public function camille_de_peretti()
   {
        $this->load->view('include/front_header_2');
		$this->load->view('front/about-us/our-students/camille_de_peretti');
		$this->load->view('include/front_footer_2');
   }

    public function johanna_loembet()
   {
        $this->load->view('include/front_header_2');
		$this->load->view('front/about-us/our-students/johanna_loembet');
		$this->load->view('include/front_footer_2');
   }

    public function olga_pischevskaya()
   {
        $this->load->view('include/front_header_2');
		$this->load->view('front/about-us/our-students/olga_pischevskaya');
		$this->load->view('include/front_footer_2');
   }
	public function contact()
	{
		$this->load->view('include/front_header_2');
		$this->load->view('front/contact/index');
		$this->load->view('include/front_footer');
	}

	public function know_what_you_want()
	{
		$this->load->view('include/front_header_2');
		$this->load->view('front/contact/know_what_you_want');
		$this->load->view('include/front_footer_2');
	}

	public function book()
	{
		$result['data']=$this->common_model->get_all_data('package');
		$this->load->view('front/book/index',$result);
	}
	function our_experts()
	{
		$this->load->view('include/front_header');
		$this->load->view('front/our-experts/index');
		$this->load->view('include/front_footer');
	}
	function profile()
	{
		$this->load->view('include/front_header');
		$this->load->view('front/our-experts/profile');
		$this->load->view('include/front_footer');
	}
	function our_services()
	{
		$this->load->view('include/front_header');
		$this->load->view('front/our_services');
		$this->load->view('include/front_footer');
	}
	function news()
	{
		$this->load->view('include/front_header_2');
		$this->load->view('front/news/news');
		$this->load->view('include/front_footer');
	}
	function booking()
	{		
		$this->load->view('front/booking');
	}
}
